package com.waheedtechblog.otpexample;


import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

import com.waheedtechblog.otp.UserInfo;

/**
 * This class will be required for Marshalling/ Unmarshalling the UserInfo
 * object.
 * @author waheedtechblog@gmail.com (Abdul Waheed)
 * 
 */
@XmlRootElement(name = "Users")
public class UserInfos {
	private ArrayList<UserInfo> users;

	/**
	 * @return the users
	 */
	public ArrayList<UserInfo> getUsers() {
		return users;
	}

	/**
	 * @param users
	 *            the users to set
	 */
	public void setUsers(ArrayList<UserInfo> users) {
		this.users = users;
	}

}
